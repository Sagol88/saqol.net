# SAQOL v1.0.0 - Windows kurulum
# Dosyalardaki "internetten indirildi" isaretini kaldirir, uygulamayi
# kullanici klasorune kurar, Masaustu ve Baslat menusune kisayol koyar.
# Eski "UDEX" kurulumu varsa kaldirilir; hesaplar ve ayarlar SAQOL'a tasinir.
$ErrorActionPreference = 'Stop'
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch {}
function Say($t, $c = 'Gray') { Write-Host $t -ForegroundColor $c }
$here = $PSScriptRoot
$src  = Join-Path $here 'SAQOL.exe'
Say ''
Say '  SAQOL v1.0.0 kuruluyor...' 'Cyan'
Say ''
if (-not (Test-Path $src)) {
  Say '  HATA: SAQOL.exe bulunamadi.' 'Red'
  Say '  Zip dosyasina sag tiklayip "Tumunu Ayikla" deyin, sonra acilan klasordeki KUR.cmd dosyasini calistirin.' 'Yellow'
  exit 1
}
# 1) Internet isaretini kaldir
Get-ChildItem -LiteralPath $here -File -Recurse | ForEach-Object { try { Unblock-File -LiteralPath $_.FullName } catch {} }
Say '  [1/4] Guvenlik isareti kaldirildi' 'Green'

# 2) Acik olan eski surumu kapat (UDEX veya SAQOL)
try { Invoke-WebRequest -UseBasicParsing -Method Post -Uri 'http://127.0.0.1:8787/api/shutdown' -TimeoutSec 3 | Out-Null } catch {}
Start-Sleep -Milliseconds 1500
foreach ($n in 'UDEX-Mailer', 'SAQOL') { Get-Process -Name $n -ErrorAction SilentlyContinue | ForEach-Object { try { $_.Kill() } catch {} } }
Start-Sleep -Milliseconds 700
Say '  [2/4] Eski surum kapatildi' 'Green'

# 3) Kullanici klasorune kur (yonetici izni gerekmez)
$dest = Join-Path $env:LOCALAPPDATA 'Programs\SAQOL'
New-Item -ItemType Directory -Force -Path $dest | Out-Null
$exe = Join-Path $dest 'SAQOL.exe'
$ok = $false
for ($i = 0; $i -lt 10 -and -not $ok; $i++) {
  try { Copy-Item -LiteralPath $src -Destination $exe -Force; $ok = $true } catch { Start-Sleep -Milliseconds 800 }
}
if (-not $ok) { Say '  HATA: Eski surum hala acik. Kapatip tekrar deneyin.' 'Red'; exit 1 }
foreach ($f in 'KULLANIM-KILAVUZU.txt', 'ornek_liste.csv') {
  $p = Join-Path $here $f; if (Test-Path $p) { Copy-Item -LiteralPath $p -Destination $dest -Force }
}
Get-ChildItem -LiteralPath $dest -File | ForEach-Object { try { Unblock-File -LiteralPath $_.FullName } catch {} }
# Eski UDEX program klasorunu kaldir (veriler kullanici klasorunde, korunur)
$oldDir = Join-Path $env:LOCALAPPDATA 'Programs\UDEX'
if (Test-Path $oldDir) { try { Remove-Item -LiteralPath $oldDir -Recurse -Force } catch {} }
Say ('  [3/4] Kuruldu: ' + $dest) 'Green'

# 4) Kisayollar
try {
  $sh = $null
  try { $sh = New-Object -ComObject WScript.Shell } catch {}
  $desk = [Environment]::GetFolderPath('Desktop'); $prog = [Environment]::GetFolderPath('Programs')
  $pins = Join-Path $env:APPDATA 'Microsoft\Internet Explorer\Quick Launch\User Pinned\TaskBar'
  $startup = [Environment]::GetFolderPath('Startup')
  foreach ($o in 'UDEX.lnk', 'UDEX Mailer.lnk', 'UD Mail.lnk') {
    foreach ($d in $desk, $prog, $pins, $startup) { $p = Join-Path $d $o; if (Test-Path $p) { try { Remove-Item -LiteralPath $p -Force } catch {} } }
  }
  foreach ($l in (Join-Path $desk 'SAQOL.lnk'), (Join-Path $prog 'SAQOL.lnk')) {
    if (-not $sh) { break }
    try {
      $s = $sh.CreateShortcut($l); $s.TargetPath = $exe; $s.WorkingDirectory = $dest
      $s.IconLocation = "$exe,0"; $s.Description = 'SAQOL - Kurumsal E-posta'; $s.Save()
    } catch {}
  }
} catch {}
Say '  [4/4] Masaustu ve Baslat menusune "SAQOL" kisayolu eklendi' 'Green'

Start-Process -FilePath $exe -WorkingDirectory $dest
Say ''
Say '  TAMAM - SAQOL v1.0.0 acildi. Bundan sonra Masaustundeki "SAQOL" simgesini kullanin.' 'Cyan'
Say ''
