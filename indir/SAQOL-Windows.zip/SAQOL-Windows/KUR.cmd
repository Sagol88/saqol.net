@echo off
title SAQOL v1.0.0 Kurulum
cd /d "%~dp0"
if not exist "%~dp0kurulum.ps1" (
  echo.
  echo  Once zip dosyasina sag tiklayip "Tumunu Ayikla" deyin,
  echo  sonra acilan klasordeki KUR.cmd dosyasini calistirin.
  echo.
  pause
  exit /b 1
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0kurulum.ps1"
if errorlevel 1 (
  echo.
  pause
  exit /b 1
)
timeout /t 6 >nul
