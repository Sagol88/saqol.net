#!/bin/bash
# SAQOL v1.0.0 — derle + Uygulamalar'a kur (tek adim). Cift tikla.
set -e
cd "$(dirname "$0")"
APP="SAQOL.app"
echo "== SAQOL v1.0.0 derleniyor =="
if ! command -v swiftc >/dev/null 2>&1; then
  echo "HATA: Xcode Command Line Tools yok. Kur: xcode-select --install"; read -p "Enter..."; exit 1
fi
xattr -dr com.apple.quarantine . 2>/dev/null || true
rm -rf "$APP"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"
if ! swiftc -O -framework Cocoa -framework WebKit -framework UserNotifications -framework AVFoundation main.swift -o "$APP/Contents/MacOS/SAQOL"; then
  echo "HATA: Uygulama derlenemedi. Eski surum yerinde birakildi."; read -p "Enter..."; exit 1
fi
# Motor: Apple Silicon + Intel (her Mac'te calissin)
if [ -f saqol-server-intel ] && command -v lipo >/dev/null 2>&1; then
  lipo -create saqol-server saqol-server-intel -output "$APP/Contents/Resources/saqol-server"
elif [ "$(uname -m)" = "x86_64" ] && [ -f saqol-server-intel ]; then
  cp saqol-server-intel "$APP/Contents/Resources/saqol-server"
else
  cp saqol-server "$APP/Contents/Resources/saqol-server"
fi
chmod +x "$APP/Contents/Resources/saqol-server"
ICN="saqol-$(date +%s).icns"   # her kurulumda yeni ad: Dock eski ikonu önbellekten göstermesin
cp saqol.icns "$APP/Contents/Resources/$ICN"
cp logo.png logo_lines.png "$APP/Contents/Resources/" 2>/dev/null || true
cat > "$APP/Contents/Info.plist" <<PL
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>CFBundleName</key><string>SAQOL</string>
  <key>CFBundleDisplayName</key><string>SAQOL</string>
  <key>CFBundleIdentifier</key><string>net.saqol.mac</string>
  <key>CFBundleVersion</key><string>10039</string>
  <key>CFBundleShortVersionString</key><string>1.0.0</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>CFBundleExecutable</key><string>SAQOL</string>
  <key>CFBundleIconFile</key><string>$ICN</string>
  <key>LSMinimumSystemVersion</key><string>11.0</string>
  <key>NSHighResolutionCapable</key><true/>
  <key>NSCameraUsageDescription</key><string>SAQOL, belgeleri kamerayla tarayıp PDF yapmak için kamerayı kullanır.</string>
  <key>NSAppTransportSecurity</key><dict><key>NSAllowsLocalNetworking</key><true/></dict>
</dict></plist>
PL
codesign --force --deep --sign - "$APP" 2>/dev/null || true
xattr -dr com.apple.quarantine "$APP" 2>/dev/null || true
echo "== Eski surum kapatiliyor =="
osascript -e 'quit app "UDEX Mailer"' 2>/dev/null || true
pkill -x "UDEX Mailer" 2>/dev/null || true
pkill -x "udex-server" 2>/dev/null || true
pkill -x "SAQOL" 2>/dev/null || true
pkill -x "Saqol" 2>/dev/null || true
pkill -x "saqol-server" 2>/dev/null || true
sleep 1
echo "== Uygulamalar'a kuruluyor =="
DEST="/Applications/SAQOL.app"
if rm -rf "$DEST" 2>/dev/null && cp -R "$APP" "/Applications/" 2>/dev/null; then
  TARGET="$DEST"
else
  mkdir -p "$HOME/Applications"; rm -rf "$HOME/Applications/SAQOL.app"
  cp -R "$APP" "$HOME/Applications/"; TARGET="$HOME/Applications/SAQOL.app"
fi
echo "KURULDU: $TARGET"
# Eski UDEX Mailer uygulamasini kaldir (veriler korunur, SAQOL'a tasinir)
rm -rf "/Applications/UDEX Mailer.app" "$HOME/Applications/UDEX Mailer.app" 2>/dev/null || true
xattr -dr com.apple.quarantine "$TARGET" 2>/dev/null || true
touch "$TARGET"
/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister -f "$TARGET" 2>/dev/null || true
UC="$(getconf DARWIN_USER_CACHE_DIR 2>/dev/null)"; [ -n "$UC" ] && rm -rf "$UC/com.apple.dock.iconcache" "$UC/com.apple.iconservices" 2>/dev/null || true
killall Dock 2>/dev/null || true
open "$TARGET"
echo ""; echo "TAMAMDIR — SAQOL v1.0.0 kuruldu ve acildi."
