import Cocoa
import WebKit
import UserNotifications
import AVFoundation

// SAQOL — native macOS app.
// Launches the bundled Go engine (server-only) and shows the UI in a native
// WKWebView window. No browser involved.

let SERVER_URL = "http://127.0.0.1:8787"

final class AppDelegate: NSObject, NSApplicationDelegate, WKNavigationDelegate, WKUIDelegate, WKScriptMessageHandler, UNUserNotificationCenterDelegate {
    var window: NSWindow!
    var webView: WKWebView!
    var server: Process?
    var quitting = false
    var restarts: [Date] = []

    func applicationDidFinishLaunching(_ notification: Notification) {
        startServer()
        buildMenu()

        let rect = NSRect(x: 0, y: 0, width: 1280, height: 860)
        window = NSWindow(contentRect: rect,
                          styleMask: [.titled, .closable, .miniaturizable, .resizable],
                          backing: .buffered, defer: false)
        window.title = "SAQOL"
        window.isReleasedWhenClosed = false
        window.center()
        window.setFrameAutosaveName("SaqolMainWindow")

        let cfg = WKWebViewConfiguration()
        cfg.userContentController.add(self, name: "saqolBadge")
        webView = WKWebView(frame: rect, configuration: cfg)
        webView.autoresizingMask = [.width, .height]
        webView.navigationDelegate = self
        webView.uiDelegate = self
        window.contentView = webView

        window.makeKeyAndOrderFront(nil)
        NSApp.activate(ignoringOtherApps: true)

        showStatus("SAQOL başlatılıyor…", retry: false)
        loadWhenReady(attempt: 0)
        NSWorkspace.shared.notificationCenter.addObserver(self, selector: #selector(didWake), name: NSWorkspace.didWakeNotification, object: nil)
        setupNotes()
    }

    // MARK: - Bildirimler: tıklayınca ilgili mail açılır
    var noteLast: Int64 = -1
    var notesOK = false
    func setupNotes() {
        let c = UNUserNotificationCenter.current()
        c.delegate = self
        c.requestAuthorization(options: [.alert, .sound, .badge]) { ok, _ in
            DispatchQueue.main.async {
                self.notesOK = ok
                guard ok else { return } // izin yoksa motor eskisi gibi sistem bildirimi gösterir
                Timer.scheduledTimer(withTimeInterval: 5, repeats: true) { _ in self.pollNotes() }
                self.pollNotes()
            }
        }
    }
    func pollNotes() {
        guard let url = URL(string: SERVER_URL + "/api/ui/notes?since=\(noteLast)") else { return }
        var req = URLRequest(url: url); req.timeoutInterval = 4
        URLSession.shared.dataTask(with: req) { data, _, _ in
            guard let d = data, let o = try? JSONSerialization.jsonObject(with: d) as? [String: Any] else { return }
            let last = (o["last"] as? NSNumber)?.int64Value ?? 0
            let notes = o["notes"] as? [[String: Any]] ?? []
            DispatchQueue.main.async {
                let first = self.noteLast < 0
                self.noteLast = last
                if first { return }
                for n in notes.suffix(5) {
                    let c = UNMutableNotificationContent()
                    c.title = n["title"] as? String ?? "SAQOL"
                    c.body = n["body"] as? String ?? ""
                    c.sound = .default
                    c.userInfo = ["acc": n["acc"] as? String ?? "", "uid": (n["uid"] as? NSNumber)?.int64Value ?? 0]
                    let id = "n-\((n["seq"] as? NSNumber)?.int64Value ?? 0)-\(Date().timeIntervalSince1970)"
                    UNUserNotificationCenter.current().add(UNNotificationRequest(identifier: id, content: c, trigger: nil))
                }
            }
        }.resume()
    }
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification,
                                withCompletionHandler done: @escaping (UNNotificationPresentationOptions) -> Void) {
        done([.banner, .list, .sound])
    }
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse,
                                withCompletionHandler done: @escaping () -> Void) {
        let info = response.notification.request.content.userInfo
        let acc = info["acc"] as? String ?? ""
        let uid = (info["uid"] as? NSNumber)?.int64Value ?? 0
        DispatchQueue.main.async {
            NSApp.activate(ignoringOtherApps: true)
            if self.window.isMiniaturized { self.window.deminiaturize(nil) }
            self.window.makeKeyAndOrderFront(nil)
            guard !acc.isEmpty, uid > 0, let url = URL(string: SERVER_URL + "/api/mail/open-req") else { return }
            var req = URLRequest(url: url)
            req.httpMethod = "POST"
            req.setValue("application/json", forHTTPHeaderField: "Content-Type")
            req.httpBody = try? JSONSerialization.data(withJSONObject: ["acc": acc, "uid": uid])
            URLSession.shared.dataTask(with: req) { _, _, _ in
                DispatchQueue.main.async { self.webView.evaluateJavaScript("window.SaqolCheckOpen&&SaqolCheckOpen()", completionHandler: nil) }
            }.resume()
        }
        done()
    }

    // Belge tarama (kamera) — yalnızca SAQOL'un kendi sayfası
    @available(macOS 12.0, *)
    func webView(_ webView: WKWebView, requestMediaCapturePermissionFor origin: WKSecurityOrigin,
                 initiatedByFrame frame: WKFrameInfo, type: WKMediaCaptureType,
                 decisionHandler: @escaping (WKPermissionDecision) -> Void) {
        guard origin.host == "127.0.0.1" else { decisionHandler(.deny); return }
        AVCaptureDevice.requestAccess(for: .video) { ok in DispatchQueue.main.async { decisionHandler(ok ? .grant : .deny) } }
    }

    func applicationShouldHandleReopen(_ sender: NSApplication, hasVisibleWindows flag: Bool) -> Bool {
        if !flag { window.makeKeyAndOrderFront(nil) }
        return true
    }

    /// Sunucu yanıt verene kadar bekler (sınırsız); uzun sürerse durum gösterir.
    func loadWhenReady(attempt: Int) {
        guard let url = URL(string: SERVER_URL + "/api/version") else { return }
        var req = URLRequest(url: url)
        req.timeoutInterval = 2
        URLSession.shared.dataTask(with: req) { _, resp, err in
            DispatchQueue.main.async {
                if err == nil, (resp as? HTTPURLResponse)?.statusCode == 200 {
                    // açılış animasyonu en az 2,2 sn görünsün (tüm platformlarda aynı)
                    let wait = max(0, 2.2 - Date().timeIntervalSince(self.splashAt))
                    DispatchQueue.main.asyncAfter(deadline: .now() + wait) { self.webView.load(URLRequest(url: URL(string: SERVER_URL)!)) }
                    return
                }
                if attempt == 30 { self.ensureServer() }   // ~10 sn: sunucu ölmüşse yeniden başlat
                if attempt == 120 {                          // ~40 sn
                    self.showStatus("SAQOL motoru yanıt vermiyor. Bilgisayarı yeniden başlatmayı veya SAQOL'u yeniden kurmayı deneyin.", retry: true)
                    return
                }
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.33) { self.loadWhenReady(attempt: attempt + 1) }
            }
        }.resume()
    }

    var splashAt = Date()
    func showStatus(_ msg: String, retry: Bool) {
        if !retry { splashAt = Date() }
        // Açılışta: logonun çizgileri üzerinde kayan ışık (dönen daire yok)
        func res64(_ n: String) -> String {
            guard let u = Bundle.main.url(forResource: n, withExtension: "png"), let d = try? Data(contentsOf: u) else { return "" }
            return "data:image/png;base64," + d.base64EncodedString()
        }
        let lines = res64("logo_lines")
        let logo = "<div class=lg><img src='\(res64("logo"))'><i style=\"-webkit-mask-image:url(\(lines))\"></i></div>"
        let body = retry ? "\(logo)<p>\(msg)</p><button onclick=\"location.href='saqol-retry://x'\">Tekrar Dene</button>" : logo
        let html = """
        <html><head><meta charset=utf-8><style>
        body{margin:0;height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;background:linear-gradient(180deg,#FFFFFF 0%,#F1F5FB 55%,#DEE8F6 100%);color:#1b2a44;font:15px -apple-system,sans-serif;text-align:center}
        p{max-width:420px;opacity:.9;line-height:1.5;margin-top:22px}
        button{margin-top:14px;padding:12px 28px;border:0;border-radius:10px;background:#1F6FEB;color:#fff;font-size:15px;font-weight:700;cursor:pointer}
        .lg{position:relative;width:300px;height:300px;max-width:78vw;max-height:78vw;animation:in .7s ease-out both}
        
        .lg img{width:100%;height:100%;display:block}
        .lg i{position:absolute;inset:0;-webkit-mask-size:100% 100%;-webkit-mask-repeat:no-repeat;background:linear-gradient(115deg,transparent 0%,transparent 34%,rgba(255,236,190,.9) 45%,#fff 50%,rgba(255,236,190,.9) 55%,transparent 66%,transparent 100%) no-repeat;background-size:300% 100%;animation:sh 2.4s cubic-bezier(.45,.05,.35,1) infinite}
        @keyframes sh{0%{background-position:120% 0}100%{background-position:-20% 0}}
        @keyframes in{from{opacity:0;transform:scale(.94)}to{opacity:1;transform:none}}
        </style></head><body>\(body)</body></html>
        """
        webView.loadHTMLString(html, baseURL: Bundle.main.resourceURL)
    }

    @objc func reloadPage() {
        if webView.url?.host == "127.0.0.1" { webView.reload() } else { showStatus("SAQOL başlatılıyor…", retry: false); ensureServer(); loadWhenReady(attempt: 0) }
    }

    @objc func didWake() {
        // Uyku sonrası: sunucu duruyorsa yeniden başlat.
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) { self.ensureServer() }
    }

    /// Sunucu süreci ölmüşse ve port yanıt vermiyorsa yeniden başlatır.
    func ensureServer() {
        if let s = server, s.isRunning { return }
        guard let url = URL(string: SERVER_URL + "/api/version") else { return }
        var req = URLRequest(url: url); req.timeoutInterval = 1.5
        URLSession.shared.dataTask(with: req) { _, resp, err in
            if err == nil { return } // başka bir SAQOL sunucusu zaten çalışıyor
            DispatchQueue.main.async {
                let now = Date()
                self.restarts = self.restarts.filter { now.timeIntervalSince($0) < 60 }
                guard self.restarts.count < 5 else { return }
                self.restarts.append(now)
                self.startServer()
            }
        }.resume()
    }

    func startServer() {
        // The Go engine binary sits in the app bundle's Resources folder.
        guard let path = Bundle.main.path(forResource: "saqol-server", ofType: nil) else {
            NSLog("saqol-server not found in bundle")
            return
        }
        let p = Process()
        p.executableURL = URL(fileURLWithPath: path)
        var env = ProcessInfo.processInfo.environment
        env["UDEX_SERVER_ONLY"] = "1"
        p.environment = env
        p.terminationHandler = { [weak self] proc in
            NSLog("saqol-server exited: \(proc.terminationStatus)")
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                guard let self = self, !self.quitting else { return }
                self.ensureServer()
            }
        }
        do {
            try p.run()
            server = p
        } catch {
            NSLog("server launch failed: \(error)")
        }
    }

    func buildMenu() {
        let mainMenu = NSMenu()
        let appItem = NSMenuItem()
        mainMenu.addItem(appItem)
        let appMenu = NSMenu()
        appMenu.addItem(withTitle: "Gizle", action: #selector(NSApplication.hide(_:)), keyEquivalent: "h")
        appMenu.addItem(NSMenuItem.separator())
        appMenu.addItem(withTitle: "Çıkış", action: #selector(NSApplication.terminate(_:)), keyEquivalent: "q")
        appItem.submenu = appMenu

        // Edit menu so copy/paste/select-all work in inputs.
        let editItem = NSMenuItem()
        mainMenu.addItem(editItem)
        let editMenu = NSMenu(title: "Düzenle")
        editMenu.addItem(withTitle: "Geri Al", action: Selector(("undo:")), keyEquivalent: "z")
        editMenu.addItem(withTitle: "Yinele", action: Selector(("redo:")), keyEquivalent: "Z")
        editMenu.addItem(NSMenuItem.separator())
        editMenu.addItem(withTitle: "Kes", action: #selector(NSText.cut(_:)), keyEquivalent: "x")
        editMenu.addItem(withTitle: "Kopyala", action: #selector(NSText.copy(_:)), keyEquivalent: "c")
        editMenu.addItem(withTitle: "Yapıştır", action: #selector(NSText.paste(_:)), keyEquivalent: "v")
        editMenu.addItem(withTitle: "Tümünü Seç", action: #selector(NSText.selectAll(_:)), keyEquivalent: "a")
        editItem.submenu = editMenu

        let viewItem = NSMenuItem()
        mainMenu.addItem(viewItem)
        let viewMenu = NSMenu(title: "Görünüm")
        let rl = NSMenuItem(title: "Yenile", action: #selector(reloadPage), keyEquivalent: "r")
        rl.target = self
        viewMenu.addItem(rl)
        viewItem.submenu = viewMenu

        let winItem = NSMenuItem()
        mainMenu.addItem(winItem)
        let winMenu = NSMenu(title: "Pencere")
        winMenu.addItem(withTitle: "Küçült", action: #selector(NSWindow.performMiniaturize(_:)), keyEquivalent: "m")
        winMenu.addItem(withTitle: "Kapat", action: #selector(NSWindow.performClose(_:)), keyEquivalent: "w")
        winItem.submenu = winMenu

        NSApp.mainMenu = mainMenu
    }

    // MARK: - Gezinme: dış linkler tarayıcıda, indirmeler İndirilenler'e

    func isLocal(_ u: URL?) -> Bool { u?.host == "127.0.0.1" || u?.scheme == "about" || u?.scheme == "data" }

    func webView(_ webView: WKWebView, decidePolicyFor action: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let u = action.request.url else { decisionHandler(.allow); return }
        if u.scheme == "saqol-retry" { decisionHandler(.cancel); reloadPage(); return }
        if isLocal(u) || action.targetFrame?.isMainFrame == false && u.scheme != "http" && u.scheme != "https" { decisionHandler(.allow); return }
        if ["http", "https", "mailto", "tel"].contains(u.scheme ?? "") {
            openExternal(u)
            decisionHandler(.cancel)
            return
        }
        decisionHandler(.allow)
    }

    // target=_blank / window.open → varsayılan tarayıcı (yerel sayfaysa aynı pencerede)
    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration,
                 for action: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if let u = action.request.url {
            if isLocal(u) { webView.load(action.request) } else { openExternal(u) }
        }
        return nil
    }

    /// Mail içindeki bağlantılar: mailto SAQOL'da yeni mail açar, gerisi tarayıcıda.
    func openExternal(_ u: URL) {
        if (u.scheme ?? "").lowercased() == "mailto" {
            let d = (try? JSONSerialization.data(withJSONObject: [u.absoluteString])) ?? Data("[\"\"]".utf8)
            let a = String(data: d, encoding: .utf8) ?? "[\"\"]"
            let js = "window.SAQOLMailto ? (SAQOLMailto(\(a.dropFirst().dropLast())), true) : false"
            webView.evaluateJavaScript(js) { r, _ in
                if (r as? Bool) != true { NSWorkspace.shared.open(u) }
            }
            return
        }
        NSWorkspace.shared.open(u)
    }

    func webView(_ webView: WKWebView, decidePolicyFor response: WKNavigationResponse,
                 decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {
        if let http = response.response as? HTTPURLResponse, let url = http.url {
            let cd = (http.value(forHTTPHeaderField: "Content-Disposition") ?? "").lowercased()
            if cd.contains("attachment") || !response.canShowMIMEType {
                decisionHandler(.cancel)
                download(url, suggested: http.suggestedFilename)
                return
            }
        }
        decisionHandler(.allow)
    }

    func download(_ url: URL, suggested: String?) {
        URLSession.shared.downloadTask(with: url) { tmp, resp, err in
            DispatchQueue.main.async {
                let code = (resp as? HTTPURLResponse)?.statusCode ?? 200
                guard let tmp = tmp, err == nil, (200..<300).contains(code) else {
                    let a = NSAlert(); a.messageText = "Dosya indirilemedi."; a.addButton(withTitle: "Tamam"); a.runModal(); return
                }
                let fm = FileManager.default
                let dir = fm.urls(for: .downloadsDirectory, in: .userDomainMask).first ?? fm.temporaryDirectory
                let name = resp?.suggestedFilename ?? suggested ?? url.lastPathComponent
                var dest = dir.appendingPathComponent(name)
                let base = dest.deletingPathExtension().lastPathComponent, ext = dest.pathExtension
                var i = 2
                while fm.fileExists(atPath: dest.path) {
                    dest = dir.appendingPathComponent(ext.isEmpty ? "\(base) (\(i))" : "\(base) (\(i)).\(ext)"); i += 1
                }
                do { try fm.moveItem(at: tmp, to: dest); NSWorkspace.shared.activateFileViewerSelecting([dest]) }
                catch { let a = NSAlert(); a.messageText = "Kaydedilemedi: \(error.localizedDescription)"; a.addButton(withTitle: "Tamam"); a.runModal() }
            }
        }.resume()
    }

    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        let code = (error as NSError).code
        if code == NSURLErrorCancelled || code == 102 { return }
        showStatus("SAQOL yeniden bağlanıyor…", retry: false)
        ensureServer()
        loadWhenReady(attempt: 0)
    }

    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) { reloadPage() }

    // Enable the "Choose File" dialog inside the WebView (CSV import).
    func webView(_ webView: WKWebView,
                 runOpenPanelWith parameters: WKOpenPanelParameters,
                 initiatedByFrame frame: WKFrameInfo,
                 completionHandler: @escaping ([URL]?) -> Void) {
        let panel = NSOpenPanel()
        panel.canChooseFiles = true
        panel.canChooseDirectories = false
        panel.allowsMultipleSelection = parameters.allowsMultipleSelection
        panel.begin { result in
            if result == .OK {
                completionHandler(panel.urls)
            } else {
                completionHandler(nil)
            }
        }
    }

    // Allow JS alert/confirm (used by "Tekrar Başla" confirm dialog).
    func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
        let a = NSAlert(); a.messageText = message; a.addButton(withTitle: "Tamam"); a.runModal(); completionHandler()
    }
    func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
        let a = NSAlert(); a.messageText = message; a.addButton(withTitle: "Tamam"); a.addButton(withTitle: "İptal")
        completionHandler(a.runModal() == .alertFirstButtonReturn)
    }

    /// Okunmamış mail sayısı → Dock simgesinde kırmızı rozet.
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard message.name == "saqolBadge" else { return }
        var n = 0
        if let v = message.body as? NSNumber { n = v.intValue } else if let v = message.body as? String { n = Int(v) ?? 0 }
        NSApp.dockTile.badgeLabel = n > 0 ? (n > 99 ? "99+" : String(n)) : nil
    }

    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool {
        return true
    }

    func applicationWillTerminate(_ notification: Notification) {
        quitting = true
        server?.terminate()
    }
}

let app = NSApplication.shared
app.setActivationPolicy(.regular)
let delegate = AppDelegate()
app.delegate = delegate
app.run()
